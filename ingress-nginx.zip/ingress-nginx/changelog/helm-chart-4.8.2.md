# Changelog

This file documents all notable changes to [ingress-nginx](https://github.com/kubernetes/ingress-nginx) Helm Chart. The release numbering uses [semantic versioning](http://semver.org).

### 4.8.2

* update nginx base, httpbun, e2e, helm webhook cert gen (#10506)
* Update Ingress-Nginx version controller-v1.9.3

**Full Changelog**: https://github.com/kubernetes/ingress-nginx/compare/helm-chart-4.8.1...helm-chart-4.8.2
